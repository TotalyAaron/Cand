#ifndef __STD__
#define __STD__
#include "scancode.h"
namespace std {
    char keymap[128] = {
        0,  27, '1','2','3','4','5','6','7','8','9','0','-','=', '\b',
        '\t','q','w','e','r','t','y','u','i','o','p','[',']','\n', 0,
        'a','s','d','f','g','h','j','k','l',';','\'','`',  0,
        '\\','z','x','c','v','b','n','m',',','.','/', 0, '*', 0, ' ', // etc...
    };
    class stdint {
    public:
        using uint8_t = unsigned char;
        using int8_t = signed char;
        using uint16_t = unsigned short;
        using int16_t = signed short;
        using uint32_t = unsigned int;
        using int32_t = signed int;
        using uint64_t = unsigned long long;
        using int64_t = signed long long;
#if defined(__x86_64__) || defined(_M_X64)
        using uintptr_t = uint64_t;
#else
        using uintptr_t = uint32_t;
#endif
    };
    class stdptr {
    public:
        using stdptr_t = stdint::uintptr_t;
    };
    constexpr const char* newline = "\n";
    constexpr const char* nullterm = "\0";
    class txtMode {
    public:
        static inline void print_string_text(const char* str) {
            asm volatile (
                "1:\n\t"
                "lodsb\n\t"          // load byte from DS:SI into AL
                "test al, al\n\t"
                "jz 2f\n\t"
                "mov ah, 0x0E\n\t"   // BIOS teletype
                "mov bh, 0\n\t"      // page number
                "mov bl, 0x0F\n\t"   // color
                "int 0x10\n\t"
                "jmp 1b\n\t"
                "2:\n\t"
                :
            : "S"(str)           // SI points to string
                : "ax", "bx"
                );
        }
        static inline void print_string_vga(const char* str) {
            volatile unsigned char* vga = (unsigned char*)0xB8000;
            while (*str) {
                if (*str == '\n') {
                    offset += (80 - (offset / 2 % 80)) * 2;
                }
                else {
                    vga[offset++] = *str;   // character
                    vga[offset++] = 0x0F;   // color
                }
                // wrap-around
                if (offset >= 80 * 25 * 2) {
                    for (int i = 0; i < 80 * 25 * 2; i += 2) {
                        vga[i] = ' ';
                        vga[i + 1] = 0x0F;
                    }
                    offset = 0;
                }
                str++;
            }
            // --------- print_string_vga is depricated. --------- //
        }
        static inline void set_video_mode(unsigned char mode) {
            asm volatile (
                "mov ah, 0x00\n\t"   // BIOS set video mode
                "mov al, %0\n\t"     // mode
                "int 0x10\n\t"
                :
            : "r"(mode)
                : "ax"
                );
        }
        inline static unsigned int offset = 0; // cursor position
        static constexpr unsigned char color = 0x0F;
        static inline void clear_screen() {
            volatile unsigned char* vga = (unsigned char*)0xB8000;
            for (int i = 0; i < 80 * 25 * 2; i += 2) {
                vga[i] = ' ';
                vga[i + 1] = color;
            }
            offset = 0;
        }
        static inline void putchar(char c) {
            volatile unsigned char* vga = (unsigned char*)0xB8000;
            if (c == '\n') {
                offset += (80 - (offset / 2 % 80)) * 2; // next line
            }
            else if (c >= 32 && c <= 126) { // only printable ASCII
                vga[offset] = c;
                vga[offset + 1] = color;
                offset += 2;
            }
            // wrap-around
            if (offset >= 80 * 25 * 2) {
                for (int i = 0; i < 80 * 25 * 2; i += 2) {
                    vga[i] = ' ';
                    vga[i + 1] = color;
                }
                offset = 0;
            }
        }
        static inline void println(char c) {
            putchar(c);
            putchar('\n'); // move to next line
        }
        static inline void print_string(const char* str) {
            while (*str) putchar(*str++);
        }
    };
    class graphicsMode {
    public:
        struct VideoInfo {
            stdint::uint16_t mode;
            stdint::uint16_t width;
            stdint::uint16_t height;
        };
        static inline VideoInfo get_video_info_basic() {
            VideoInfo info;
            unsigned char al;
            asm volatile(
                "mov ah, 0x0F\n\t"
                "int 0x10\n\t"
                "mov %0, al\n\t"
                : "=r"(al)
                :
                : "ah"
                );
            info.mode = al;
            switch (al) {
            case 0x03: info.width = 80;  info.height = 25; break;  // text mode
            case 0x13: info.width = 320; info.height = 200; break; // VGA 256-color
            case 0x12: info.width = 640; info.height = 480; break; // VGA 16-color
            default:   info.width = 0;   info.height = 0;   break;
            }
            return info;
        }
        static inline void put_pixel(unsigned int x, unsigned int y, unsigned char color, VideoInfo vi) {
            if (x >= vi.width || y >= vi.height) return;
            // VGA graphics memory starts at 0xA0000 in mode 0x13
            volatile unsigned char* vga = (unsigned char*)0xA0000;
            // Compute offset in the framebuffer
            unsigned int offset = y * vi.width + x;
            vga[offset] = color;
        }
    };
    class sixteenbit {
    public:
        struct GDTEntry {
            stdint::uint16_t limit_low;
            stdint::uint16_t base_low;
            stdint::uint8_t  base_mid;
            stdint::uint8_t  access;
            stdint::uint8_t  granularity;
            stdint::uint8_t  base_high;
        } __attribute__((packed));
        static inline GDTEntry gdt[3];
        struct GDTDescriptor {
            stdint::uint16_t limit;
            stdint::uint32_t base;
        } __attribute__((packed));
        static GDTDescriptor gdt_ptr_original;
        static inline void enable_pm(stdint::uint32_t gdt_ptr) {
            asm volatile (
                "cli\n\t"
                "lgdt (%0)\n\t"
                "mov eax, cr0\n\t"
                "or eax, 1\n\t"
                "mov cr0, eax\n\t"
                "jmp 0x08, protected_entry\n\t"
                "protected_entry:\n\t"
                "mov ax, 0x10\n\t"
                "mov ds, ax\n\t"
                "mov es, ax\n\t"
                "mov ss, ax\n\t"
                "mov esp, 0x90000\n\t"
                :
            : "r"(gdt_ptr)
                : "eax"
                );
        }
        struct Key {
            unsigned char ascii;
            unsigned char scancode;
        };
        static inline Key getch_scancode() {
            Key k;
            asm volatile (
                "xor ah, ah\n\t"
                "int 0x16\n\t"
                "mov %0, al\n\t"   // ASCII
                "mov %1, ah\n\t"   // Scan code
                : "=r"(k.ascii), "=r"(k.scancode)
                :
                : "ax"
                );
            return k;
        }
    };
    class thritytwobit {
    public:
        static inline void jump(stdptr::stdptr_t addr) {
            asm volatile(
                "jmp *%0"
                :
            : "r"(addr)
                );
        }
        static inline stdint::uint8_t inb(stdint::uint16_t port) {
            stdint::uint8_t ret;
            asm volatile ("inb %1, %0" : "=a"(ret) : "Nd"(port));
            return ret;
        }
        static inline void outb(stdint::uint16_t port, stdint::uint8_t val) {
            asm volatile ("outb %0, %1" : : "a"(val), "Nd"(port));
        }
        static char getch() {
            // Wait until output buffer full (bit 0 of status register)
            while ((inb(0x64) & 0x01) == 0);
            stdint::uint8_t scancode = inb(0x60);
            if (scancode & 0x80) {
                // key release, ignore for now
                return 0;
            }
            extern char keymap[128];
            return keymap[scancode];
        }
    };
}
std::sixteenbit::GDTDescriptor std::sixteenbit::gdt_ptr_original = {
    sizeof(std::sixteenbit::gdt) - 1,
    (std::stdint::uint32_t)&std::sixteenbit::gdt
};
#endif
